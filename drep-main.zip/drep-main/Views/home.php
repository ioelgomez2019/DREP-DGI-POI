<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>DREP-CEPLAN</title>
</head>
<body>
    <p>Mini Framework planificacion POI V1.1 - <a href="http://localhost/tienda_poiv6/dashboard">www.drep.dgi.com</a></p>
</body>
</html>